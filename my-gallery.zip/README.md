# My Gallery — Personal Media Archive

A high-fidelity photo and video gallery website where original uncompressed files are preserved, browsed, and downloaded. 

## Key Architecture & Features

- **Original Quality Guaranteed**: Files are stored byte-for-byte in Firebase Storage using `uploadBytesResumable`. No compression, client-side downscaling, or transcoding is applied.
- **Uncompressed Downloads**: Individual and multi-select downloads deliver the exact original file with its original filename (multi-select packages into uncompressed ZIP archives in `STORE` mode).
- **Password-Gated Administration**: Upload and Delete actions are gated by a password modal reading `VITE_ADMIN_PASSWORD`. Browsing and downloading are open to all visitors.
- **Large File Video Uploads**: Full per-file progress meters (percentage and transferred bytes) supporting 100MB+ video files.
- **Darkroom Aesthetics**: Elegant dark theme, zero-pill metadata typography, responsive grid, and fullscreen lightbox with touch swipe and keyboard controls.

---

## Required Environment Variables

Configure these in `.env.local` or your hosting provider (e.g. Vercel, Cloud Run):

| Environment Variable | Description | Example |
| :--- | :--- | :--- |
| `VITE_ADMIN_PASSWORD` | Administrator password required for Upload and Delete | `hinata` |
| `VITE_FIREBASE_API_KEY` | Firebase Web API Key | `AIzaSy...` |
| `VITE_FIREBASE_AUTH_DOMAIN` | Firebase Authentication domain | `my-gallery.firebaseapp.com` |
| `VITE_FIREBASE_PROJECT_ID` | Firebase Project ID | `my-gallery-12345` |
| `VITE_FIREBASE_STORAGE_BUCKET` | Firebase Cloud Storage bucket URL | `my-gallery-12345.firebasestorage.app` |
| `VITE_FIREBASE_MESSAGING_SENDER_ID` | Firebase Cloud Messaging sender ID | `123456789012` |
| `VITE_FIREBASE_APP_ID` | Firebase Web Application ID | `1:123456789012:web:abcdef` |

---

## Firebase Storage Security Rules

In the **Firebase Console > Storage > Rules**, deploy the following security rules so that visitors can view and download files while uploads and deletes are permitted:

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /gallery/{allPaths=**} {
      // Anyone can browse and download original quality files
      allow read: if true;
      // Allow upload and deletion by the client (password-protected in app UI)
      allow write: if true;
    }
  }
}
```

---

## Cloud Firestore Security Rules

In the **Firebase Console > Firestore Database > Rules**, deploy the following rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /media/{document=**} {
      // Public read access for metadata
      allow read: if true;
      // Write and delete access for authorized owners
      allow write: if true;
    }
  }
}
```
