import React, { useState, useEffect, useCallback } from 'react';
import { MediaItem, FilterType, SortOrder, ToastMessage } from './types';
import { fetchMediaItems, deleteMediaItem, isFirebaseConfigured } from './lib/firebase';
import { downloadSelectedFiles } from './lib/download';
import { Header } from './components/Header';
import { Gallery } from './components/Gallery';
import { Lightbox } from './components/Lightbox';
import { UploadModal } from './components/UploadModal';
import { PasswordModal } from './components/PasswordModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { ConfigGuideModal } from './components/ConfigGuideModal';
import { Toast } from './components/Toast';
import { Database, AlertTriangle } from 'lucide-react';

export default function App() {
  const [items, setItems] = useState<MediaItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState<FilterType>('all');
  const [sortOrder, setSortOrder] = useState<SortOrder>('newest');

  // Multi-selection state
  const [selectedItems, setSelectedItems] = useState<MediaItem[]>([]);
  const [isSelectMode, setIsSelectMode] = useState(false);

  // Lightbox state
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  // Modal states
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [configGuideOpen, setConfigGuideOpen] = useState(false);

  // Password verification modal state
  const [passwordModal, setPasswordModal] = useState<{
    isOpen: boolean;
    actionTitle: string;
    onSuccessAction: () => void;
  }>({
    isOpen: false,
    actionTitle: '',
    onSuccessAction: () => {},
  });

  // Deletion confirmation modal state
  const [deleteConfirm, setDeleteConfirm] = useState<{
    isOpen: boolean;
    items: MediaItem[];
  }>({
    isOpen: false,
    items: [],
  });
  const [isDeleting, setIsDeleting] = useState(false);

  // Toast messages
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback(
    (type: 'success' | 'error' | 'info', message: string) => {
      const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
      setToasts((prev) => [...prev, { id, type, message }]);
    },
    []
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Load media items on mount
  const loadMedia = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await fetchMediaItems();
      setItems(data);
    } catch (err: any) {
      console.error('Failed to load media:', err);
      addToast('error', 'Could not fetch gallery items. Please check your network or Firebase rules.');
    } finally {
      setIsLoading(false);
    }
  }, [addToast]);

  useEffect(() => {
    loadMedia();
  }, [loadMedia]);

  // Handle password-gated Upload trigger
  const handleUploadClick = () => {
    setPasswordModal({
      isOpen: true,
      actionTitle: 'Upload Media',
      onSuccessAction: () => {
        setUploadModalOpen(true);
      },
    });
  };

  // Handle single item deletion request (Password check -> Confirmation -> Delete)
  const handleRequestDelete = (item: MediaItem) => {
    setPasswordModal({
      isOpen: true,
      actionTitle: `Delete "${item.name}"`,
      onSuccessAction: () => {
        setDeleteConfirm({
          isOpen: true,
          items: [item],
        });
      },
    });
  };

  // Handle batch deletion request (Password check -> Confirmation -> Delete)
  const handleDeleteSelected = () => {
    if (selectedItems.length === 0) return;
    setPasswordModal({
      isOpen: true,
      actionTitle: `Delete ${selectedItems.length} selected files`,
      onSuccessAction: () => {
        setDeleteConfirm({
          isOpen: true,
          items: selectedItems,
        });
      },
    });
  };

  // Execute deletion after confirmation
  const handleConfirmDelete = async () => {
    if (deleteConfirm.items.length === 0) return;
    setIsDeleting(true);

    const count = deleteConfirm.items.length;
    addToast('info', `Deleting ${count} ${count === 1 ? 'file' : 'files'}...`);

    let successCount = 0;
    const deletedIds = new Set<string>();

    for (const item of deleteConfirm.items) {
      try {
        await deleteMediaItem(item);
        deletedIds.add(item.id);
        successCount++;
      } catch (err) {
        console.error('Failed to delete item:', item.name, err);
      }
    }

    setItems((prev) => prev.filter((i) => !deletedIds.has(i.id)));
    setSelectedItems((prev) => prev.filter((i) => !deletedIds.has(i.id)));
    setIsDeleting(false);
    setDeleteConfirm({ isOpen: false, items: [] });

    if (successCount === count) {
      addToast('success', `Permanently removed ${count} ${count === 1 ? 'file' : 'files'}.`);
    } else {
      addToast('error', `Removed ${successCount} of ${count} files. Some could not be deleted.`);
    }
  };

  // Handle download of selected items
  const handleDownloadSelected = async () => {
    if (selectedItems.length === 0) return;
    addToast('info', `Packaging ${selectedItems.length} original files...`);
    try {
      await downloadSelectedFiles(selectedItems, (pct, currentFile) => {
        if (pct === 100) {
          addToast('info', 'Generating uncompressed archive...');
        }
      });
      addToast('success', `Downloaded ${selectedItems.length} uncompressed original files.`);
    } catch {
      addToast('error', 'Failed to bundle and download selected files.');
    }
  };

  // Selection toggle
  const handleSelectToggle = (item: MediaItem) => {
    setSelectedItems((prev) => {
      const exists = prev.some((i) => i.id === item.id);
      if (exists) {
        return prev.filter((i) => i.id !== item.id);
      } else {
        return [...prev, item];
      }
    });
  };

  const handleToggleSelectMode = () => {
    setIsSelectMode((prev) => {
      if (prev) {
        setSelectedItems([]); // Clear on cancel
      }
      return !prev;
    });
  };

  // Open item in lightbox
  const handleItemClick = (item: MediaItem) => {
    const idx = items.findIndex((i) => i.id === item.id);
    if (idx !== -1) {
      setLightboxIndex(idx);
      setLightboxOpen(true);
    }
  };

  const handleUploadSuccess = (newItem: MediaItem) => {
    setItems((prev) => [newItem, ...prev.filter((i) => i.id !== newItem.id)]);
  };

  const hasConfig = isFirebaseConfigured();

  return (
    <div className="min-h-screen bg-[#08090d] text-slate-100 flex flex-col font-sans">
      {/* Firebase Status Banner (shown if environment credentials pending) */}
      {!hasConfig && (
        <div className="bg-[#12141f] border-b border-amber-500/20 px-4 py-2 text-xs text-slate-300">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-2">
              <Database className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>
                Demo Vault Active: Using high-fidelity sample files. Connect your live Firebase in{' '}
                <code className="text-amber-300 font-mono">.env.local</code> to save to Cloud Storage.
              </span>
            </div>
            <button
              onClick={() => setConfigGuideOpen(true)}
              className="text-amber-400 hover:text-amber-300 underline underline-offset-2 font-medium shrink-0"
            >
              Setup Guide & Rules
            </button>
          </div>
        </div>
      )}

      {/* Header with Top Bar Contract & Hero */}
      <Header
        onUploadClick={handleUploadClick}
        onOpenConfigGuide={() => setConfigGuideOpen(true)}
        selectedCount={selectedItems.length}
        isSelectMode={isSelectMode}
        onToggleSelectMode={handleToggleSelectMode}
        onDownloadSelected={handleDownloadSelected}
        onDeleteSelected={handleDeleteSelected}
      />

      {/* Gallery Section */}
      <main className="flex-1">
        <Gallery
          items={items}
          isLoading={isLoading}
          filter={filter}
          sortOrder={sortOrder}
          selectedItems={selectedItems}
          isSelectMode={isSelectMode}
          onFilterChange={setFilter}
          onSortChange={setSortOrder}
          onToggleSelectMode={handleToggleSelectMode}
          onSelectToggle={handleSelectToggle}
          onItemClick={handleItemClick}
          onRequestDelete={handleRequestDelete}
          onOpenUpload={handleUploadClick}
          onToast={addToast}
        />
      </main>

      {/* Clean minimal footer */}
      <footer className="border-t border-slate-900 bg-[#06070a] py-8 text-center text-xs text-slate-600">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-slate-500">
            basha as · Personal uncompressed media archive
          </p>
          <p className="text-slate-600">
            Original quality preserved · Zero compression
          </p>
        </div>
      </footer>

      {/* Fullscreen Lightbox */}
      <Lightbox
        items={items}
        currentIndex={lightboxIndex}
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        onNavigate={setLightboxIndex}
        onToast={addToast}
      />

      {/* Upload Modal (Gated by Password) */}
      <UploadModal
        isOpen={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        onUploadSuccess={handleUploadSuccess}
        onToast={addToast}
      />

      {/* Password Gate Modal */}
      <PasswordModal
        isOpen={passwordModal.isOpen}
        actionTitle={passwordModal.actionTitle}
        onClose={() => setPasswordModal((prev) => ({ ...prev, isOpen: false }))}
        onSuccess={passwordModal.onSuccessAction}
      />

      {/* Permanent Deletion Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={deleteConfirm.isOpen}
        itemsToDelete={deleteConfirm.items}
        isDeleting={isDeleting}
        onClose={() => setDeleteConfirm({ isOpen: false, items: [] })}
        onConfirm={handleConfirmDelete}
      />

      {/* Configuration & Rules Guide Modal */}
      <ConfigGuideModal
        isOpen={configGuideOpen}
        onClose={() => setConfigGuideOpen(false)}
        onToast={addToast}
      />

      {/* Toast Notification Layer */}
      <Toast toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
