import React, { useState } from 'react';
import { X, Copy, Check, ShieldCheck, Database, Key } from 'lucide-react';

interface ConfigGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onToast: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const ConfigGuideModal: React.FC<ConfigGuideModalProps> = ({
  isOpen,
  onClose,
  onToast,
}) => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, section: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(section);
    onToast('success', `Copied ${section} to clipboard!`);
    setTimeout(() => setCopiedSection(null), 2500);
  };

  const envTemplate = `# Administrator Password for Upload and Delete
VITE_ADMIN_PASSWORD="hinata"

# Firebase Web App Credentials (from Firebase Console > Project Settings)
VITE_FIREBASE_API_KEY="your-api-key"
VITE_FIREBASE_AUTH_DOMAIN="your-project.firebaseapp.com"
VITE_FIREBASE_PROJECT_ID="your-project-id"
VITE_FIREBASE_STORAGE_BUCKET="your-project.appspot.com"
VITE_FIREBASE_MESSAGING_SENDER_ID="1234567890"
VITE_FIREBASE_APP_ID="1:1234567890:web:abcdef123456"`;

  const storageRules = `rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /gallery/{allPaths=**} {
      // Allow anyone (friends/public) to view and download files
      allow read: if true;
      // Allow upload and deletion by the client (password gated in app)
      allow write: if true;
    }
  }
}`;

  const firestoreRules = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /media/{document=**} {
      // Anyone can read metadata to browse and download originals
      allow read: if true;
      // App client writes/deletes metadata upon password verification
      allow write: if true;
    }
  }
}`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-2xl bg-[#0f1118] border border-slate-800 rounded-2xl shadow-2xl flex flex-col max-h-[90vh] text-slate-100 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold tracking-tight text-white">Firebase & Environment Setup</h2>
              <p className="text-xs text-slate-400">Configuration keys & required security rules</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded-lg transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-6 text-xs text-slate-300">
          {/* Admin Password & Env section */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Key className="w-4 h-4 text-amber-400" />
                <span>Environment Variables (.env.local)</span>
              </h3>
              <button
                onClick={() => copyToClipboard(envTemplate, 'Environment Template')}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
              >
                {copiedSection === 'Environment Template' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>Copy .env</span>
              </button>
            </div>
            <pre className="p-3 bg-[#14161f] rounded-xl border border-slate-800/80 font-mono text-[11px] text-slate-300 overflow-x-auto leading-relaxed">
              {envTemplate}
            </pre>
          </div>

          {/* Firebase Storage Rules */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-sky-400" />
                <span>Firebase Storage Rules (storage.rules)</span>
              </h3>
              <button
                onClick={() => copyToClipboard(storageRules, 'Storage Rules')}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
              >
                {copiedSection === 'Storage Rules' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>Copy Rules</span>
              </button>
            </div>
            <p className="text-slate-400 mb-2">
              In Firebase Console &gt; Storage &gt; Rules, paste this rule so anyone can read and download files:
            </p>
            <pre className="p-3 bg-[#14161f] rounded-xl border border-slate-800/80 font-mono text-[11px] text-slate-300 overflow-x-auto leading-relaxed">
              {storageRules}
            </pre>
          </div>

          {/* Cloud Firestore Rules */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Database className="w-4 h-4 text-emerald-400" />
                <span>Cloud Firestore Rules (firestore.rules)</span>
              </h3>
              <button
                onClick={() => copyToClipboard(firestoreRules, 'Firestore Rules')}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
              >
                {copiedSection === 'Firestore Rules' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>Copy Rules</span>
              </button>
            </div>
            <p className="text-slate-400 mb-2">
              In Firebase Console &gt; Firestore Database &gt; Rules, paste this rule:
            </p>
            <pre className="p-3 bg-[#14161f] rounded-xl border border-slate-800/80 font-mono text-[11px] text-slate-300 overflow-x-auto leading-relaxed">
              {firestoreRules}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 flex justify-end bg-[#12141d]">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-colors shadow-sm"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
