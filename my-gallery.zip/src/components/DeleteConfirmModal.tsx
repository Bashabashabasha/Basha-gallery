import React from 'react';
import { Trash2, AlertTriangle, X } from 'lucide-react';
import { MediaItem } from '../types';
import { formatBytes } from '../lib/formatters';

interface DeleteConfirmModalProps {
  isOpen: boolean;
  itemsToDelete: MediaItem[];
  isDeleting: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  isOpen,
  itemsToDelete,
  isDeleting,
  onClose,
  onConfirm,
}) => {
  if (!isOpen || itemsToDelete.length === 0) return null;

  const totalBytes = itemsToDelete.reduce((sum, item) => sum + item.size, 0);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-150"
      onClick={(e) => {
        if (!isDeleting && e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-md bg-[#0f1118] border border-rose-500/20 rounded-2xl p-6 shadow-2xl text-slate-100">
        {!isDeleting && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded-lg transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
            <Trash2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-semibold tracking-tight text-white">
              {itemsToDelete.length === 1 ? 'Delete Media File' : `Delete ${itemsToDelete.length} Media Files`}
            </h3>
            <p className="text-xs text-rose-400/90 font-medium">Permanent deletion warning</p>
          </div>
        </div>

        <p className="text-sm text-slate-300 mb-4 leading-relaxed">
          Are you sure you want to delete {itemsToDelete.length === 1 ? 'this file' : 'these files'}?{' '}
          This action will permanently erase the uncompressed files ({formatBytes(totalBytes)}) from Firebase Storage and Cloud Firestore. This cannot be undone.
        </p>

        <div className="max-h-40 overflow-y-auto mb-5 p-3 rounded-xl bg-[#161922] border border-slate-800 divide-y divide-slate-800/60">
          {itemsToDelete.map((item) => (
            <div key={item.id} className="py-2 first:pt-0 last:pb-0 flex items-center justify-between text-xs">
              <span className="truncate max-w-[220px] text-slate-300 font-medium">{item.name}</span>
              <span className="text-slate-500 font-mono tabular-nums">{formatBytes(item.size)}</span>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-end gap-3">
          <button
            type="button"
            disabled={isDeleting}
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded-xl transition-colors disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={isDeleting}
            onClick={onConfirm}
            className="px-4 py-2 text-xs font-medium text-white bg-rose-600 hover:bg-rose-500 disabled:opacity-50 rounded-xl transition-colors flex items-center gap-2 shadow-sm"
          >
            {isDeleting ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Deleting...</span>
              </>
            ) : (
              <>
                <Trash2 className="w-3.5 h-3.5" />
                <span>Confirm Permanent Delete</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
