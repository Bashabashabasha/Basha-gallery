import React, { useMemo } from 'react';
import {
  Layers,
  Image as ImageIcon,
  Film,
  ArrowUpDown,
  CheckSquare,
  Upload,
  HardDrive,
  FolderOpen,
} from 'lucide-react';
import { MediaItem, FilterType, SortOrder } from '../types';
import { MediaCard } from './MediaCard';
import { formatBytes } from '../lib/formatters';

interface GalleryProps {
  items: MediaItem[];
  isLoading: boolean;
  filter: FilterType;
  sortOrder: SortOrder;
  selectedItems: MediaItem[];
  isSelectMode: boolean;
  onFilterChange: (filter: FilterType) => void;
  onSortChange: (sort: SortOrder) => void;
  onToggleSelectMode: () => void;
  onSelectToggle: (item: MediaItem) => void;
  onItemClick: (item: MediaItem) => void;
  onRequestDelete: (item: MediaItem) => void;
  onOpenUpload: () => void;
  onToast: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const Gallery: React.FC<GalleryProps> = ({
  items,
  isLoading,
  filter,
  sortOrder,
  selectedItems,
  isSelectMode,
  onFilterChange,
  onSortChange,
  onToggleSelectMode,
  onSelectToggle,
  onItemClick,
  onRequestDelete,
  onOpenUpload,
  onToast,
}) => {
  // Counts calculation
  const totalCount = items.length;
  const photoCount = items.filter((i) => i.type === 'image').length;
  const videoCount = items.filter((i) => i.type === 'video').length;
  const totalBytes = items.reduce((sum, i) => sum + i.size, 0);

  // Filter & Sort
  const filteredItems = useMemo(() => {
    let result = [...items];

    if (filter === 'image') {
      result = result.filter((i) => i.type === 'image');
    } else if (filter === 'video') {
      result = result.filter((i) => i.type === 'video');
    }

    if (sortOrder === 'newest') {
      result.sort((a, b) => b.createdAt - a.createdAt);
    } else if (sortOrder === 'oldest') {
      result.sort((a, b) => a.createdAt - b.createdAt);
    }

    return result;
  }, [items, filter, sortOrder]);

  return (
    <section id="gallery" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Controls Bar: Filters, Sort, Multi-Select, Counters */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
        {/* Segmented Filter Tabs */}
        <div className="flex items-center gap-1 p-1 bg-[#12141d] border border-slate-800 rounded-xl">
          <button
            onClick={() => onFilterChange('all')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
              filter === 'all'
                ? 'bg-amber-400 text-slate-950 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>All ({totalCount})</span>
          </button>

          <button
            onClick={() => onFilterChange('image')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
              filter === 'image'
                ? 'bg-amber-400 text-slate-950 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Photos ({photoCount})</span>
          </button>

          <button
            onClick={() => onFilterChange('video')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
              filter === 'video'
                ? 'bg-amber-400 text-slate-950 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            <span>Videos ({videoCount})</span>
          </button>
        </div>

        {/* Right Tools: Stats, Sort Dropdown, Select Mode Toggle */}
        <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end flex-wrap">
          {/* Unboxed Metadata Stats */}
          <div className="hidden lg:flex items-center gap-1.5 text-xs text-slate-500 font-mono tabular-nums">
            <HardDrive className="w-3.5 h-3.5 text-slate-600" />
            <span>{formatBytes(totalBytes)} Vault</span>
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-1.5 text-xs text-slate-400 bg-[#12141d] border border-slate-800 px-2.5 py-1.5 rounded-xl">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
            <select
              value={sortOrder}
              onChange={(e) => onSortChange(e.target.value as SortOrder)}
              className="bg-transparent text-slate-300 focus:outline-none cursor-pointer"
            >
              <option value="newest" className="bg-[#12141d] text-white">Newest First</option>
              <option value="oldest" className="bg-[#12141d] text-white">Oldest First</option>
            </select>
          </div>

          {/* Multi-Select Toggle */}
          <button
            onClick={onToggleSelectMode}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-xl border transition-colors ${
              isSelectMode
                ? 'bg-amber-400/10 border-amber-400 text-amber-300'
                : 'bg-[#12141d] border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <CheckSquare className="w-3.5 h-3.5" />
            <span>{isSelectMode ? 'Cancel Selection' : 'Select'}</span>
          </button>
        </div>
      </div>

      {/* Media Grid or States */}
      <div className="mt-8">
        {isLoading ? (
          // Skeleton Loading Grid
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {Array.from({ length: 8 }).map((_, idx) => (
              <div
                key={idx}
                className="bg-[#0f1118] border border-slate-800/60 rounded-2xl overflow-hidden animate-pulse"
              >
                <div className="aspect-4/3 bg-slate-800/40" />
                <div className="p-3.5 space-y-2.5">
                  <div className="h-4 bg-slate-800/60 rounded w-3/4" />
                  <div className="h-3 bg-slate-800/40 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredItems.length === 0 ? (
          // Empty State
          <div className="text-center py-20 px-4 border border-dashed border-slate-800/80 rounded-3xl bg-[#0b0d13]/50">
            <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-slate-800/50 flex items-center justify-center text-slate-400">
              <FolderOpen className="w-7 h-7" />
            </div>
            <h3 className="text-lg font-semibold text-white">
              {filter === 'all'
                ? 'Your gallery archive is empty'
                : `No ${filter === 'image' ? 'photos' : 'videos'} found`}
            </h3>
            <p className="mt-1 text-sm text-slate-400 max-w-sm mx-auto">
              Upload personal photos or videos in full original fidelity.
            </p>
            <button
              onClick={onOpenUpload}
              className="mt-5 inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-colors shadow-sm"
            >
              <Upload className="w-4 h-4" />
              <span>Upload Media</span>
            </button>
          </div>
        ) : (
          // Media Grid
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {filteredItems.map((item) => {
              const isSelected = selectedItems.some((s) => s.id === item.id);
              return (
                <MediaCard
                  key={item.id}
                  item={item}
                  isSelected={isSelected}
                  isSelectMode={isSelectMode}
                  onSelectToggle={onSelectToggle}
                  onClick={onItemClick}
                  onRequestDelete={onRequestDelete}
                  onToast={onToast}
                />
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};
