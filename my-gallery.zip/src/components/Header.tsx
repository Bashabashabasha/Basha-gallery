import React from 'react';
import { Upload, Download, Trash2, HelpCircle, Layers, CheckSquare, X } from 'lucide-react';
import { MediaItem } from '../types';

interface HeaderProps {
  onUploadClick: () => void;
  onOpenConfigGuide: () => void;
  selectedCount: number;
  isSelectMode: boolean;
  onToggleSelectMode: () => void;
  onDownloadSelected: () => void;
  onDeleteSelected: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onUploadClick,
  onOpenConfigGuide,
  selectedCount,
  isSelectMode,
  onToggleSelectMode,
  onDownloadSelected,
  onDeleteSelected,
}) => {
  return (
    <>
      {/* Top Bar following 3-Zone Contract */}
      <header className="sticky top-0 z-40 bg-[#08090d]/85 backdrop-blur-md border-b border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Brand title wordmark */}
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold tracking-tight text-white whitespace-nowrap shrink-0">
              basha as
            </span>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
            <a
              href="#gallery"
              className="hover:text-white transition-colors whitespace-nowrap shrink-0"
            >
              Archive
            </a>
            <button
              onClick={onOpenConfigGuide}
              className="flex items-center gap-1.5 hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Firebase Setup & Rules</span>
            </button>
          </nav>

          {/* Zone 3: Primary Action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenConfigGuide}
              className="md:hidden p-2 text-slate-400 hover:text-white hover:bg-slate-800/60 rounded-xl transition-colors"
              title="Firebase Setup Guide"
            >
              <HelpCircle className="w-4 h-4" />
            </button>

            <button
              onClick={onUploadClick}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all shadow-sm hover:shadow-amber-500/20 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>Upload</span>
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="border-b border-slate-800/60 bg-gradient-to-b from-[#0c0e14] to-[#08090d] py-10 sm:py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-white leading-tight">
              Personal Media Archive
            </h1>
            <p className="mt-3 text-sm sm:text-base text-slate-400 leading-relaxed">
              Every photo and video is stored and served in its untouched, original quality. Friends can freely browse and download uncompressed files; uploads and deletions are reserved for the gallery owner.
            </p>
          </div>
        </div>
      </section>

      {/* Sticky Selection Toolbar (Active when in selection mode) */}
      {isSelectMode && (
        <div className="sticky top-16 z-30 bg-[#12141e] border-b border-amber-500/30 px-4 sm:px-6 py-2.5 shadow-xl transition-all animate-in fade-in">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-2 text-xs text-amber-300 font-medium">
              <CheckSquare className="w-4 h-4" />
              <span>
                {selectedCount === 0
                  ? 'Click items to select'
                  : `${selectedCount} ${selectedCount === 1 ? 'file' : 'files'} selected`}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={onDownloadSelected}
                disabled={selectedCount === 0}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Selected</span>
              </button>

              <button
                onClick={onDeleteSelected}
                disabled={selectedCount === 0}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Selected</span>
              </button>

              <button
                onClick={onToggleSelectMode}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors"
                title="Cancel selection"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
