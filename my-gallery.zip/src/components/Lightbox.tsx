import React, { useEffect, useState, useRef, useCallback } from 'react';
import {
  X,
  ChevronLeft,
  ChevronRight,
  Download,
  Maximize2,
  Minimize2,
  Calendar,
  HardDrive,
  Film,
  Image as ImageIcon,
} from 'lucide-react';
import { MediaItem } from '../types';
import { formatBytes, formatDate, formatDuration } from '../lib/formatters';
import { downloadOriginalFile } from '../lib/download';

interface LightboxProps {
  items: MediaItem[];
  currentIndex: number;
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (newIndex: number) => void;
  onToast: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const Lightbox: React.FC<LightboxProps> = ({
  items,
  currentIndex,
  isOpen,
  onClose,
  onNavigate,
  onToast,
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [touchStartX, setTouchStartX] = useState<number | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const currentItem: MediaItem | undefined = items[currentIndex];

  const handlePrev = useCallback(() => {
    if (items.length <= 1) return;
    const nextIdx = (currentIndex - 1 + items.length) % items.length;
    onNavigate(nextIdx);
  }, [currentIndex, items.length, onNavigate]);

  const handleNext = useCallback(() => {
    if (items.length <= 1) return;
    const nextIdx = (currentIndex + 1) % items.length;
    onNavigate(nextIdx);
  }, [currentIndex, items.length, onNavigate]);

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowLeft') {
        handlePrev();
      } else if (e.key === 'ArrowRight') {
        handleNext();
      } else if (e.key === 'f' || e.key === 'F') {
        toggleFullscreen();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, handlePrev, handleNext, onClose]);

  // Mobile swipe gestures
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStartX(e.touches[0].clientX);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX === null) return;
    const touchEndX = e.changedTouches[0].clientX;
    const diff = touchEndX - touchStartX;

    if (Math.abs(diff) > 50) {
      if (diff > 0) {
        handlePrev();
      } else {
        handleNext();
      }
    }
    setTouchStartX(null);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  const handleDownload = async () => {
    if (!currentItem || isDownloading) return;
    setIsDownloading(true);
    onToast('info', `Starting download: "${currentItem.name}" (Original Quality)`);
    try {
      await downloadOriginalFile(currentItem);
      onToast('success', `Downloaded "${currentItem.name}"`);
    } catch {
      onToast('error', `Failed to download "${currentItem.name}"`);
    } finally {
      setIsDownloading(false);
    }
  };

  if (!isOpen || !currentItem) return null;

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-50 flex flex-col bg-black/95 backdrop-blur-xl text-slate-100 select-none animate-in fade-in duration-200"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Top Header Bar */}
      <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 bg-black/50 border-b border-white/10 z-10">
        <div className="flex items-center gap-3 min-w-0 pr-4">
          <span className="text-xs text-amber-400 font-mono tabular-nums shrink-0 font-medium">
            {currentIndex + 1} / {items.length}
          </span>
          <span className="text-white/20">·</span>
          <h3 className="text-sm font-medium text-slate-200 truncate">
            {currentItem.name}
          </h3>
          <span className="hidden sm:inline text-xs text-slate-400 font-mono tabular-nums">
            ({formatBytes(currentItem.size)})
          </span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleDownload}
            disabled={isDownloading}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-semibold transition-colors shadow-sm disabled:opacity-50"
            title="Download exact original file"
          >
            <Download className="w-4 h-4" />
            <span className="hidden xs:inline">Download Original</span>
          </button>

          <button
            onClick={toggleFullscreen}
            className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors hidden sm:block"
            aria-label={isFullscreen ? 'Exit fullscreen' : 'Enter fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          <button
            onClick={onClose}
            className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
            aria-label="Close lightbox"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Viewport */}
      <div className="relative flex-1 flex items-center justify-center p-2 sm:p-6 overflow-hidden">
        {/* Navigation Arrows */}
        {items.length > 1 && (
          <>
            <button
              onClick={handlePrev}
              className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 z-20 p-2.5 sm:p-3 rounded-full bg-black/60 hover:bg-black/80 text-white/80 hover:text-white border border-white/10 transition-all hover:scale-105"
              aria-label="Previous item"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            <button
              onClick={handleNext}
              className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 z-20 p-2.5 sm:p-3 rounded-full bg-black/60 hover:bg-black/80 text-white/80 hover:text-white border border-white/10 transition-all hover:scale-105"
              aria-label="Next item"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </>
        )}

        {/* Media Container */}
        <div className="relative max-w-full max-h-full flex items-center justify-center">
          {currentItem.type === 'video' ? (
            <video
              key={currentItem.id}
              src={currentItem.downloadUrl}
              controls
              autoPlay
              playsInline
              className="max-h-[75vh] sm:max-h-[82vh] max-w-[95vw] sm:max-w-[85vw] rounded-lg shadow-2xl bg-black"
            >
              Your browser does not support the video tag.
            </video>
          ) : (
            <img
              key={currentItem.id}
              src={currentItem.downloadUrl}
              alt={currentItem.name}
              referrerPolicy="no-referrer"
              className="max-h-[75vh] sm:max-h-[82vh] max-w-[95vw] sm:max-w-[85vw] object-contain rounded-lg shadow-2xl transition-opacity duration-200"
            />
          )}
        </div>
      </div>

      {/* Bottom Info Bar */}
      <div className="px-4 sm:px-6 py-2.5 bg-black/60 border-t border-white/10 text-xs text-slate-400 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-1.5">
            {currentItem.type === 'video' ? (
              <Film className="w-3.5 h-3.5 text-violet-400" />
            ) : (
              <ImageIcon className="w-3.5 h-3.5 text-sky-400" />
            )}
            <span className="capitalize">{currentItem.type}</span>
          </div>

          <span className="text-white/20">·</span>

          <div className="flex items-center gap-1.5">
            <HardDrive className="w-3.5 h-3.5 text-slate-400" />
            <span className="font-mono tabular-nums">{formatBytes(currentItem.size)}</span>
          </div>

          {currentItem.duration !== undefined && currentItem.duration > 0 && (
            <>
              <span className="text-white/20">·</span>
              <span className="font-mono tabular-nums">Duration: {formatDuration(currentItem.duration)}</span>
            </>
          )}

          {currentItem.width && currentItem.height && (
            <>
              <span className="text-white/20">·</span>
              <span className="font-mono tabular-nums">{currentItem.width} × {currentItem.height}</span>
            </>
          )}

          <span className="text-white/20">·</span>

          <div className="flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span>{formatDate(currentItem.createdAt)}</span>
          </div>
        </div>

        <div className="text-[11px] text-slate-500 hidden md:block">
          Use ← → arrows to navigate · Esc to close · F for fullscreen
        </div>
      </div>
    </div>
  );
};
