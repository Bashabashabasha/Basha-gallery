import React, { useState } from 'react';
import { Play, Download, Trash2, Check, Film, Image as ImageIcon } from 'lucide-react';
import { MediaItem } from '../types';
import { formatBytes, formatDate, formatDuration } from '../lib/formatters';
import { downloadOriginalFile } from '../lib/download';

interface MediaCardProps {
  item: MediaItem;
  isSelected: boolean;
  isSelectMode: boolean;
  onSelectToggle: (item: MediaItem) => void;
  onClick: (item: MediaItem) => void;
  onRequestDelete: (item: MediaItem) => void;
  onToast: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const MediaCard: React.FC<MediaCardProps> = ({
  item,
  isSelected,
  isSelectMode,
  onSelectToggle,
  onClick,
  onRequestDelete,
  onToast,
}) => {
  const [isDownloading, setIsDownloading] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);

  const handleDownload = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isDownloading) return;
    setIsDownloading(true);
    onToast('info', `Downloading original: "${item.name}"`);
    try {
      await downloadOriginalFile(item);
      onToast('success', `Downloaded "${item.name}"`);
    } catch {
      onToast('error', `Failed to download "${item.name}"`);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    onRequestDelete(item);
  };

  const handleCardClick = (e: React.MouseEvent) => {
    if (isSelectMode) {
      onSelectToggle(item);
    } else {
      onClick(item);
    }
  };

  return (
    <div
      onClick={handleCardClick}
      className={`group relative flex flex-col bg-[#0e1017] rounded-2xl overflow-hidden border transition-all duration-200 cursor-pointer ${
        isSelected
          ? 'border-amber-400 ring-2 ring-amber-400/40 bg-[#12141e]'
          : 'border-slate-800/80 hover:border-slate-700 hover:shadow-xl hover:shadow-black/50'
      }`}
    >
      {/* Media Thumbnail Container */}
      <div className="relative aspect-4/3 w-full bg-[#13151f] overflow-hidden flex items-center justify-center">
        {item.type === 'video' ? (
          <>
            <video
              src={item.downloadUrl}
              preload="metadata"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 pointer-events-none"
            />
            {/* Play overlay button */}
            <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/20 transition-colors">
              <div className="w-12 h-12 rounded-full bg-black/60 backdrop-blur-md border border-white/20 flex items-center justify-center text-white shadow-lg group-hover:scale-110 group-hover:bg-amber-400 group-hover:text-slate-950 transition-all duration-200">
                <Play className="w-5 h-5 fill-current ml-0.5" />
              </div>
            </div>

            {/* Video duration badge */}
            {item.duration !== undefined && item.duration > 0 && (
              <div className="absolute bottom-2.5 right-2.5 px-2 py-0.5 bg-black/80 backdrop-blur-sm rounded-md text-[11px] font-mono tabular-nums text-white/90 border border-white/10">
                {formatDuration(item.duration)}
              </div>
            )}
          </>
        ) : (
          <>
            {/* Skeleton shimmer before load */}
            {!imageLoaded && (
              <div className="absolute inset-0 bg-slate-800/30 animate-pulse flex items-center justify-center">
                <ImageIcon className="w-8 h-8 text-slate-700" />
              </div>
            )}
            <img
              src={item.downloadUrl}
              alt={item.name}
              loading="lazy"
              referrerPolicy="no-referrer"
              onLoad={() => setImageLoaded(true)}
              className={`w-full h-full object-cover group-hover:scale-105 transition-all duration-300 ${
                imageLoaded ? 'opacity-100' : 'opacity-0'
              }`}
            />
          </>
        )}

        {/* Multi-select checkbox indicator */}
        <div
          className={`absolute top-2.5 left-2.5 transition-opacity ${
            isSelectMode || isSelected ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
          }`}
          onClick={(e) => {
            e.stopPropagation();
            onSelectToggle(item);
          }}
        >
          <div
            className={`w-6 h-6 rounded-lg border flex items-center justify-center transition-all ${
              isSelected
                ? 'bg-amber-400 border-amber-400 text-slate-950 shadow-sm'
                : 'bg-black/60 border-white/30 text-transparent hover:border-white'
            }`}
          >
            <Check className="w-3.5 h-3.5 stroke-[3]" />
          </div>
        </div>

        {/* Quick action buttons overlay */}
        <div className="absolute top-2.5 right-2.5 flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={handleDownload}
            disabled={isDownloading}
            className="p-2 rounded-lg bg-black/75 hover:bg-amber-400 hover:text-slate-950 text-white backdrop-blur-md border border-white/10 transition-colors shadow-sm"
            title="Download original file"
            aria-label="Download original file"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleDelete}
            className="p-2 rounded-lg bg-black/75 hover:bg-rose-600 text-white backdrop-blur-md border border-white/10 transition-colors shadow-sm"
            title="Delete file"
            aria-label="Delete file"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Card Metadata Footer (Zero-pill text typography) */}
      <div className="p-3.5 flex flex-col justify-between flex-1 gap-2">
        <div>
          <h4
            className="text-sm font-medium text-slate-200 truncate group-hover:text-amber-300 transition-colors"
            title={item.name}
          >
            {item.name}
          </h4>
          <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-1">
            <span className="capitalize">{item.type}</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="font-mono tabular-nums">{formatBytes(item.size)}</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>{formatDate(item.createdAt)}</span>
          </div>
        </div>

        {/* Always visible download & delete action row */}
        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2 mt-auto">
          <button
            onClick={handleDownload}
            disabled={isDownloading}
            className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-amber-300 transition-colors font-medium py-1 disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Original</span>
          </button>

          <button
            onClick={handleDelete}
            className="text-xs text-slate-400 hover:text-rose-400 transition-colors p-1 rounded hover:bg-slate-800/40"
            title="Delete from archive"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
