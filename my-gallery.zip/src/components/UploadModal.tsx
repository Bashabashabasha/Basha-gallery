import React, { useState, useRef, useCallback } from 'react';
import {
  Upload,
  X,
  FileImage,
  FileVideo,
  CheckCircle2,
  AlertCircle,
  HardDrive,
  Trash2,
  ShieldCheck,
} from 'lucide-react';
import { UploadItem, MediaItem } from '../types';
import { formatBytes } from '../lib/formatters';
import { uploadMediaFile } from '../lib/firebase';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadSuccess: (item: MediaItem) => void;
  onToast: (type: 'success' | 'error' | 'info', message: string) => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onUploadSuccess,
  onToast,
}) => {
  const [queue, setQueue] = useState<UploadItem[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFiles = (files: FileList | null) => {
    if (!files || files.length === 0) return;

    const newItems: UploadItem[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const isVideo = file.type.startsWith('video/');
      const isImage = file.type.startsWith('image/');

      if (!isVideo && !isImage) {
        onToast('error', `Skipped "${file.name}": Only images and videos are supported.`);
        continue;
      }

      newItems.push({
        id: `upload-${Date.now()}-${i}-${Math.random().toString(36).substr(2, 5)}`,
        file,
        name: file.name,
        size: file.size,
        type: isVideo ? 'video' : 'image',
        status: 'pending',
        progress: 0,
        bytesTransferred: 0,
      });
    }

    setQueue((prev) => [...prev, ...newItems]);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  const removeItem = (id: string) => {
    setQueue((prev) => {
      const item = prev.find((i) => i.id === id);
      if (item?.cancelFn) {
        item.cancelFn();
      }
      return prev.filter((i) => i.id !== id);
    });
  };

  const startUploads = async () => {
    const pendingItems = queue.filter((item) => item.status === 'pending');
    if (pendingItems.length === 0) return;

    setIsProcessing(true);

    for (const item of pendingItems) {
      setQueue((prev) =>
        prev.map((i) => (i.id === item.id ? { ...i, status: 'uploading' } : i))
      );

      try {
        const { promise, cancel } = uploadMediaFile(
          item.file,
          (progress, bytesTransferred) => {
            setQueue((prev) =>
              prev.map((i) =>
                i.id === item.id ? { ...i, progress, bytesTransferred } : i
              )
            );
          }
        );

        setQueue((prev) =>
          prev.map((i) => (i.id === item.id ? { ...i, cancelFn: cancel } : i))
        );

        const uploadedMedia = await promise;

        setQueue((prev) =>
          prev.map((i) =>
            i.id === item.id
              ? { ...i, status: 'completed', progress: 100, bytesTransferred: item.size }
              : i
          )
        );

        onUploadSuccess(uploadedMedia);
        onToast('success', `Uploaded "${item.name}" in original quality.`);
      } catch (err: any) {
        const errMsg = err?.message || 'Upload failed';
        setQueue((prev) =>
          prev.map((i) =>
            i.id === item.id ? { ...i, status: 'error', error: errMsg } : i
          )
        );
        onToast('error', `Failed to upload "${item.name}": ${errMsg}`);
      }
    }

    setIsProcessing(false);
  };

  const completedCount = queue.filter((i) => i.status === 'completed').length;
  const pendingCount = queue.filter((i) => i.status === 'pending').length;
  const uploadingCount = queue.filter((i) => i.status === 'uploading').length;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150"
      onClick={(e) => {
        if (!isProcessing && e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-2xl bg-[#0f1118] border border-slate-800 rounded-2xl shadow-2xl flex flex-col max-h-[90vh] text-slate-100 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold tracking-tight text-white">Upload Original Media</h2>
              <p className="text-xs text-slate-400 flex items-center gap-1.5 mt-0.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Zero compression · Exact original files stored & served</span>
              </p>
            </div>
          </div>
          {!isProcessing && (
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded-lg transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* Dropzone */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`cursor-pointer rounded-2xl border-2 border-dashed p-8 text-center transition-all ${
              isDragging
                ? 'border-amber-400 bg-amber-500/5 scale-[0.99]'
                : 'border-slate-800 hover:border-slate-700 bg-[#14161f]/50 hover:bg-[#14161f]'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*,video/*"
              className="hidden"
              onChange={(e) => {
                handleFiles(e.target.files);
                if (fileInputRef.current) fileInputRef.current.value = '';
              }}
            />
            <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-slate-800/80 flex items-center justify-center text-slate-300">
              <HardDrive className="w-6 h-6" />
            </div>
            <p className="text-sm font-medium text-slate-200">
              Drag & drop photos or videos here, or <span className="text-amber-400 underline decoration-amber-400/40 underline-offset-4">browse</span>
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Supports RAW, JPEG, PNG, WEBP, MP4, MOV, ProRes, 4K+ videos (&gt;100 MB).
            </p>
          </div>

          {/* Queue List */}
          {queue.length > 0 && (
            <div className="space-y-2.5">
              <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                <span>Queued Files ({queue.length})</span>
                <span className="font-mono tabular-nums">
                  {formatBytes(queue.reduce((acc, curr) => acc + curr.size, 0))} Total
                </span>
              </div>

              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {queue.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 bg-[#161922] border border-slate-800/80 rounded-xl space-y-2 transition-colors"
                  >
                    <div className="flex items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2.5 min-w-0">
                        {item.type === 'video' ? (
                          <FileVideo className="w-4 h-4 text-violet-400 shrink-0" />
                        ) : (
                          <FileImage className="w-4 h-4 text-sky-400 shrink-0" />
                        )}
                        <span className="truncate text-slate-200 font-medium">{item.name}</span>
                        <span className="text-slate-500 font-mono tabular-nums shrink-0">
                          {formatBytes(item.size)}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {item.status === 'completed' && (
                          <span className="flex items-center gap-1 text-emerald-400 text-xs">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Done
                          </span>
                        )}
                        {item.status === 'error' && (
                          <span className="flex items-center gap-1 text-rose-400 text-xs" title={item.error}>
                            <AlertCircle className="w-3.5 h-3.5" /> Failed
                          </span>
                        )}
                        {item.status === 'uploading' && (
                          <span className="text-amber-400 font-mono tabular-nums text-xs">
                            {item.progress}%
                          </span>
                        )}
                        {item.status === 'pending' && !isProcessing && (
                          <button
                            onClick={() => removeItem(item.id)}
                            className="text-slate-500 hover:text-rose-400 transition-colors p-1"
                            title="Remove from queue"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Per-file Progress Bar */}
                    {(item.status === 'uploading' || item.status === 'completed') && (
                      <div className="space-y-1">
                        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className={`h-full transition-all duration-150 ${
                              item.status === 'completed' ? 'bg-emerald-400' : 'bg-amber-400'
                            }`}
                            style={{ width: `${item.progress}%` }}
                          />
                        </div>
                        <div className="flex justify-between text-[10px] text-slate-500 font-mono tabular-nums">
                          <span>{formatBytes(item.bytesTransferred)} transferred</span>
                          <span>{item.progress}%</span>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="p-4 border-t border-slate-800/80 flex items-center justify-between bg-[#12141d]">
          <div className="text-xs text-slate-400">
            {completedCount > 0 && `${completedCount} completed `}
            {uploadingCount > 0 && `· ${uploadingCount} uploading `}
            {pendingCount > 0 && `· ${pendingCount} pending`}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              disabled={isProcessing}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded-xl transition-colors disabled:opacity-50"
            >
              {completedCount > 0 && pendingCount === 0 ? 'Close' : 'Cancel'}
            </button>

            {pendingCount > 0 && (
              <button
                onClick={startUploads}
                disabled={isProcessing}
                className="px-4 py-2 text-xs font-medium text-slate-950 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 rounded-xl transition-colors flex items-center gap-2 shadow-sm font-semibold"
              >
                {isProcessing ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-slate-950/30 border-t-slate-950 rounded-full animate-spin" />
                    <span>Uploading...</span>
                  </>
                ) : (
                  <>
                    <Upload className="w-3.5 h-3.5" />
                    <span>Upload {pendingCount} {pendingCount === 1 ? 'File' : 'Files'}</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
