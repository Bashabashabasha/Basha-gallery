import JSZip from 'jszip';
import { MediaItem } from '../types';

/**
 * Download a single media item in its exact original quality with its original filename.
 */
export async function downloadOriginalFile(item: MediaItem): Promise<void> {
  try {
    const response = await fetch(item.downloadUrl, { mode: 'cors' });
    if (!response.ok) {
      throw new Error(`Failed to fetch file: ${response.statusText}`);
    }
    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = objectUrl;
    link.download = item.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(objectUrl), 2000);
  } catch {
    // Direct fallback if fetch/CORS is restricted by environment
    const link = document.createElement('a');
    link.href = item.downloadUrl;
    link.download = item.name;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}

/**
 * Download multiple selected original files.
 * If 1 item, downloads directly with original filename.
 * If multiple items, bundles them into an uncompressed ZIP archive (STORE mode) so that
 * all files retain 100% of their exact original bytes and quality.
 */
export async function downloadSelectedFiles(
  items: MediaItem[],
  onProgress?: (percent: number, currentFile: string) => void
): Promise<void> {
  if (items.length === 0) return;

  if (items.length === 1) {
    await downloadOriginalFile(items[0]);
    return;
  }

  const zip = new JSZip();

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    if (onProgress) {
      onProgress(Math.round(((i) / items.length) * 100), item.name);
    }

    try {
      const response = await fetch(item.downloadUrl, { mode: 'cors' });
      if (!response.ok) throw new Error('Fetch failed');
      const blob = await response.blob();
      // Store without compression to ensure 100% original byte preservation
      zip.file(item.name, blob, { binary: true });
    } catch {
      // If individual fetch fails, fall back to triggering browser download
      await downloadOriginalFile(item);
    }
  }

  if (onProgress) {
    onProgress(100, 'Packaging archive...');
  }

  const zipBlob = await zip.generateAsync({
    type: 'blob',
    compression: 'STORE', // No compression, exact original bytes
  });

  const objectUrl = URL.createObjectURL(zipBlob);
  const link = document.createElement('a');
  link.href = objectUrl;
  link.download = `gallery_originals_${Date.now()}.zip`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(objectUrl), 2000);
}
