import { initializeApp, getApps, getApp, type FirebaseApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  addDoc,
  getDocs,
  deleteDoc,
  doc,
  query,
  orderBy,
  type Firestore,
} from 'firebase/firestore';
import {
  getStorage,
  ref,
  uploadBytesResumable,
  getDownloadURL,
  deleteObject,
  type FirebaseStorage,
  type UploadTask,
} from 'firebase/storage';
import { MediaItem } from '../types';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || '',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || '',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || '',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || '',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '',
};

/**
 * Checks if real Firebase environment credentials have been supplied.
 */
export function isFirebaseConfigured(): boolean {
  return Boolean(
    firebaseConfig.apiKey &&
    firebaseConfig.projectId &&
    firebaseConfig.storageBucket &&
    !firebaseConfig.apiKey.includes('MY_') &&
    firebaseConfig.apiKey.length > 5
  );
}

let app: FirebaseApp | null = null;
let db: Firestore | null = null;
let storage: FirebaseStorage | null = null;

if (isFirebaseConfigured()) {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    db = getFirestore(app);
    storage = getStorage(app);
  } catch (err) {
    console.warn('Firebase initialization error:', err);
  }
}

// Initial high-fidelity demo sample items for immediate preview if Firebase isn't hooked up yet
const SAMPLE_ITEMS: MediaItem[] = [
  {
    id: 'demo-1',
    name: 'alps_mountain_vista_original.jpg',
    type: 'image',
    mimeType: 'image/jpeg',
    size: 8420194, // 8.4 MB
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 3, // 3 days ago
    downloadUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=2400&q=100',
    storagePath: 'gallery/demo-1-alps.jpg',
    width: 2400,
    height: 1600,
  },
  {
    id: 'demo-2',
    name: 'coastal_horizon_4k.mp4',
    type: 'video',
    mimeType: 'video/mp4',
    size: 148209120, // 148.2 MB (> 100 MB test)
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 7,
    downloadUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    storagePath: 'gallery/demo-2-coastal.mp4',
    duration: 15,
  },
  {
    id: 'demo-3',
    name: 'tokyo_rain_nightscape.jpg',
    type: 'image',
    mimeType: 'image/jpeg',
    size: 12582912, // 12.6 MB
    createdAt: Date.now() - 1000 * 60 * 60 * 12, // 12 hours ago
    downloadUrl: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=2400&q=100',
    storagePath: 'gallery/demo-3-tokyo.jpg',
    width: 2400,
    height: 1594,
  },
  {
    id: 'demo-4',
    name: 'drone_forest_canopy_cinema.mp4',
    type: 'video',
    mimeType: 'video/mp4',
    size: 92400192, // 92.4 MB
    createdAt: Date.now() - 1000 * 60 * 60 * 48,
    downloadUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
    storagePath: 'gallery/demo-4-drone.mp4',
    duration: 60,
  },
  {
    id: 'demo-5',
    name: 'desert_stargazing_timelapse.jpg',
    type: 'image',
    mimeType: 'image/jpeg',
    size: 16840291, // 16.8 MB
    createdAt: Date.now() - 1000 * 60 * 60 * 80,
    downloadUrl: 'https://images.unsplash.com/photo-1509773896068-7fd415d91e2e?auto=format&fit=crop&w=2400&q=100',
    storagePath: 'gallery/demo-5-desert.jpg',
    width: 2400,
    height: 1600,
  },
];

// Fallback in-memory list for demo/unconfigured sessions
let localMemoryVault: MediaItem[] = [...SAMPLE_ITEMS];

/**
 * Fetch all media metadata items from Firestore (or fallback vault)
 */
export async function fetchMediaItems(): Promise<MediaItem[]> {
  if (isFirebaseConfigured() && db) {
    try {
      const q = query(collection(db, 'media'), orderBy('createdAt', 'desc'));
      const querySnapshot = await getDocs(q);
      const items: MediaItem[] = [];
      querySnapshot.forEach((docSnapshot) => {
        const data = docSnapshot.data();
        items.push({
          id: docSnapshot.id,
          name: data.name || 'Untitled',
          type: data.type || (data.mimeType?.startsWith('video/') ? 'video' : 'image'),
          mimeType: data.mimeType || 'application/octet-stream',
          size: Number(data.size) || 0,
          createdAt: Number(data.createdAt) || Date.now(),
          downloadUrl: data.downloadUrl || '',
          storagePath: data.storagePath || '',
          duration: data.duration,
          width: data.width,
          height: data.height,
        });
      });
      return items;
    } catch (error) {
      console.error('Error fetching from Firestore:', error);
      throw error;
    }
  }

  // Fallback to local memory vault
  return [...localMemoryVault].sort((a, b) => b.createdAt - a.createdAt);
}

/**
 * Inspect video or image dimensions and duration without altering or re-encoding the file
 */
export async function inspectFileMetadata(
  file: File
): Promise<{ duration?: number; width?: number; height?: number }> {
  const isVideo = file.type.startsWith('video/');
  const isImage = file.type.startsWith('image/');

  if (isVideo) {
    return new Promise((resolve) => {
      const video = document.createElement('video');
      video.preload = 'metadata';
      const objUrl = URL.createObjectURL(file);
      video.onloadedmetadata = () => {
        URL.revokeObjectURL(objUrl);
        resolve({
          duration: Math.round(video.duration || 0),
          width: video.videoWidth || undefined,
          height: video.videoHeight || undefined,
        });
      };
      video.onerror = () => {
        URL.revokeObjectURL(objUrl);
        resolve({});
      };
      video.src = objUrl;
    });
  }

  if (isImage) {
    return new Promise((resolve) => {
      const img = new Image();
      const objUrl = URL.createObjectURL(file);
      img.onload = () => {
        URL.revokeObjectURL(objUrl);
        resolve({
          width: img.naturalWidth || undefined,
          height: img.naturalHeight || undefined,
        });
      };
      img.onerror = () => {
        URL.revokeObjectURL(objUrl);
        resolve({});
      };
      img.src = objUrl;
    });
  }

  return {};
}

/**
 * Upload a media file in its EXACT original quality without compression or transcoding.
 * Returns the created MediaItem with original filename, exact size, and download URL.
 */
export function uploadMediaFile(
  file: File,
  onProgress: (progress: number, bytesTransferred: number) => void
): { promise: Promise<MediaItem>; cancel: () => void } {
  let cancelTask = () => {};

  const promise = new Promise<MediaItem>(async (resolve, reject) => {
    try {
      const isVideo = file.type.startsWith('video/');
      const fileType = isVideo ? 'video' : 'image';

      // 1. Inspect metadata without altering file content
      const { duration, width, height } = await inspectFileMetadata(file);

      // 2. Real Firebase upload path if configured
      if (isFirebaseConfigured() && storage && db) {
        const timestamp = Date.now();
        // Sanitize path safe key while retaining original filename
        const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
        const storagePath = `gallery/${timestamp}_${safeName}`;
        const fileRef = ref(storage, storagePath);

        // Upload original untouched bytes using resumable task for progress monitoring
        const uploadTask: UploadTask = uploadBytesResumable(fileRef, file, {
          contentType: file.type || 'application/octet-stream',
          customMetadata: {
            originalName: file.name,
            originalSize: file.size.toString(),
          },
        });

        cancelTask = () => uploadTask.cancel();

        uploadTask.on(
          'state_changed',
          (snapshot) => {
            const progress = snapshot.totalBytes > 0
              ? Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100)
              : 0;
            onProgress(progress, snapshot.bytesTransferred);
          },
          (error) => {
            console.error('Firebase Storage upload error:', error);
            reject(error);
          },
          async () => {
            try {
              const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);

              const metadataDoc = {
                name: file.name,
                type: fileType,
                mimeType: file.type || (isVideo ? 'video/mp4' : 'image/jpeg'),
                size: file.size,
                createdAt: timestamp,
                downloadUrl,
                storagePath,
                duration: duration || null,
                width: width || null,
                height: height || null,
              };

              const docRef = await addDoc(collection(db!, 'media'), metadataDoc);

              const createdItem: MediaItem = {
                id: docRef.id,
                name: file.name,
                type: fileType,
                mimeType: file.type || (isVideo ? 'video/mp4' : 'image/jpeg'),
                size: file.size,
                createdAt: timestamp,
                downloadUrl,
                storagePath,
                duration,
                width,
                height,
              };

              resolve(createdItem);
            } catch (firestoreErr) {
              reject(firestoreErr);
            }
          }
        );
        return;
      }

      // 3. Simulated progress for demo vault when Firebase keys are pending
      let bytesTransferred = 0;
      const totalBytes = file.size;
      const step = Math.max(1024 * 1024, Math.floor(totalBytes / 20)); // ~5% step

      let isCanceled = false;
      cancelTask = () => {
        isCanceled = true;
      };

      const interval = setInterval(() => {
        if (isCanceled) {
          clearInterval(interval);
          reject(new Error('Upload canceled by user'));
          return;
        }

        bytesTransferred = Math.min(totalBytes, bytesTransferred + step);
        const progress = Math.round((bytesTransferred / totalBytes) * 100);
        onProgress(progress, bytesTransferred);

        if (bytesTransferred >= totalBytes) {
          clearInterval(interval);

          // Create local Object URL representing the exact original file
          const blobUrl = URL.createObjectURL(file);
          const newItem: MediaItem = {
            id: `local-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
            name: file.name,
            type: fileType,
            mimeType: file.type || (isVideo ? 'video/mp4' : 'image/jpeg'),
            size: file.size,
            createdAt: Date.now(),
            downloadUrl: blobUrl,
            storagePath: `demo/${file.name}`,
            duration,
            width,
            height,
          };

          localMemoryVault.unshift(newItem);
          resolve(newItem);
        }
      }, 120);
    } catch (err) {
      reject(err);
    }
  });

  return { promise, cancel: cancelTask };
}

/**
 * Permanently delete a media item from both Firebase Storage and Firestore
 */
export async function deleteMediaItem(item: MediaItem): Promise<void> {
  if (isFirebaseConfigured() && storage && db) {
    // 1. Delete file object from Storage
    if (item.storagePath) {
      try {
        const fileRef = ref(storage, item.storagePath);
        await deleteObject(fileRef);
      } catch (storageErr) {
        console.warn('Storage file deletion note (may already be removed):', storageErr);
      }
    }

    // 2. Delete metadata record from Firestore
    await deleteDoc(doc(db, 'media', item.id));
    return;
  }

  // Fallback deletion in demo vault
  localMemoryVault = localMemoryVault.filter((i) => i.id !== item.id);
}
