export interface MediaItem {
  id: string;
  name: string;
  type: 'image' | 'video';
  mimeType: string;
  size: number; // in bytes
  createdAt: number; // unix timestamp in ms
  downloadUrl: string;
  storagePath: string;
  duration?: number; // seconds for videos
  width?: number;
  height?: number;
}

export type FilterType = 'all' | 'image' | 'video';
export type SortOrder = 'newest' | 'oldest';

export interface UploadItem {
  id: string;
  file: File;
  name: string;
  size: number;
  type: 'image' | 'video';
  status: 'pending' | 'uploading' | 'completed' | 'error';
  progress: number; // 0 to 100
  bytesTransferred: number;
  error?: string;
  cancelFn?: () => void;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}
